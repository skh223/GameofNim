import java.util.Scanner;

public class Player 
{
    private String name = "";
    private int losses = 0;
    
    public Player()
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Please, enter your name: ");
        name = sc.nextLine();
        losses = 0;
    }
    public Player(String inputName)
    {
        name = inputName;
        losses = 0;
    }

    public int getLosses()
    {
        return losses;
    }
    public String getName()
    {
        return name;
    }

    public void addLoss()
    {
        losses += 1;
    }
}