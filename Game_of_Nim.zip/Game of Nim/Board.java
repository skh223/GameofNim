import java.util.Random;

public class Board 
{
    private static int numPieces;

    public static void generateBoard()
    {
        Random random = new Random();
        numPieces = random.nextInt(41) + 10; 
    }

    public static int getNumPieces()
    {
        return numPieces;
    }

    public static void removePieces(int pieces)
    {
        numPieces -= pieces;
    }
}
