import java.util.Random;
import java.util.Scanner;

public class Game
{
    private Player player1;
    private Player player2;

    //constructor
    public Game()
    {
        player1 = new Player();
        player2 = new Player();
    }

    public void play()
    {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        int currentPlayer = rand.nextInt(2) + 1;
        boolean playAgain = true;

        //actually plays
        while(playAgain)
        {
            Board.generateBoard();
            while(Board.getNumPieces() != 1)
            {
                System.out.println("Currently, there seems to be " + Board.getNumPieces() + " pieces on the board.");
                if(currentPlayer == 1)
                {
                    System.out.println("It's " + player1.getName() + "'s turn. ");
                }
                else if(currentPlayer == 2)
                {
                    System.out.println("It's " + player2.getName() + "'s turn. ");
                }

                System.out.print("How many do you take? ");
                int takeAmount = sc.nextInt();
                while(takeAmount > Board.getNumPieces()/2)
                {
                    System.out.println("Take no more than half the available pieces.");
                    System.out.print("How many do you take? ");
                    takeAmount = sc.nextInt();
                }
                Board.removePieces(takeAmount);
                if(currentPlayer == 1)
                {
                    currentPlayer = 2;
                }
                else if(currentPlayer == 2)
                {
                    currentPlayer = 1;
                }
            }

            if(currentPlayer == 1)
            {
                System.out.println(player1.getName() + " You lose! Better luck next time!");
                player1.addLoss();
            }
            else if(currentPlayer == 2)
            {
                System.out.println(player2.getName() + " You lose! Better luck next time!");
                player2.addLoss();
            }

            System.out.print("Play again? (ANSWER true OR false) ");
            playAgain = sc.nextBoolean();
        }
        
        System.out.println("\n" + player1.getName() + " lost " + player1.getLosses() + " time(s).");
        System.out.println(player2.getName() + " lost " + player2.getLosses() + " time(s).");
    }
}